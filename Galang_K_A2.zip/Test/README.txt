Name: Kaye Galang
ID: 2429149
Course: CPSC 350
Assignment: Mario Project
Files: "Level.cpp", "Level.h", "main.cpp", "Mario.cpp", "Mario.h", "World.cpp", "World.h", "input-spec.txt"
Sources:
- Keira Ryan who took the class last semester helped me put the output in a log.txt file 
- srand: https://www.geeksforgeeks.org/rand-and-srand-in-ccpp/
- Brendan Chen who took the class last semester helped me figure out a seg fault which was basically my Level default constructor was making a 0x0 2D array and
it did not like, so he told me to make it a nullptr
- Lindsey Lee who is taking the class right now reminded me how to get command line arguments